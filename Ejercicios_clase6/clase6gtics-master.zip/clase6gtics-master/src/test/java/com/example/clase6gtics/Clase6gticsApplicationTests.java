package com.example.clase6gtics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase6gticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
