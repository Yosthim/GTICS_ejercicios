package com.example.clase6gtics.dto;

public interface EmpleadosPorPaisDto {
    String getPais();
    int getCantidad();
}
