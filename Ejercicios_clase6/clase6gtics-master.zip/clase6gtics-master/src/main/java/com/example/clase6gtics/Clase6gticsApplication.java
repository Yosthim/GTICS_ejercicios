package com.example.clase6gtics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase6gticsApplication {

    public static void main(String[] args) {
        SpringApplication.run(Clase6gticsApplication.class, args);
    }

}
