package com.example.laboratorio4.entity;

import javax.persistence.*;


@Entity
@Table(name="employees")
public class Employees {

    //COMPLETAR
}
